# 포트폴리오 파이프라인 — 설치 & 사용 가이드

## 파일 구성

```
받은 파일 목록:
├── 00_CLAUDE.md              → 프로젝트 루트에 CLAUDE.md 로 복사
├── 01_planner.md             → .claude/agents/planner.md 로 복사
├── 02_architect.md           → .claude/agents/architect.md 로 복사
├── 03_designer.md            → .claude/agents/designer.md 로 복사
├── 04_builder.md             → .claude/agents/builder.md 로 복사
├── 05_reviewer.md            → .claude/agents/reviewer.md 로 복사
├── 06_deployer.md            → .claude/agents/deployer.md 로 복사
└── commands/
    ├── plan.md               → .claude/commands/plan.md 로 복사
    ├── design.md             → .claude/commands/design.md 로 복사
    ├── generate.md           → .claude/commands/generate.md 로 복사
    ├── build.md              → .claude/commands/build.md 로 복사
    ├── review.md             → .claude/commands/review.md 로 복사
    └── deploy.md             → .claude/commands/deploy.md 로 복사
```

---

## 설치 방법

### 1. 프로젝트 폴더 생성

```bash
mkdir my-portfolio
cd my-portfolio
```

### 2. 폴더 구조 생성

```bash
mkdir -p .claude/agents
mkdir -p .claude/commands
mkdir -p docs
mkdir -p src
```

### 3. 파일 복사

```bash
# 하네스 파일
cp 00_CLAUDE.md CLAUDE.md

# 에이전트 파일 (파일명에서 앞 번호 제거)
cp 01_planner.md   .claude/agents/planner.md
cp 02_architect.md .claude/agents/architect.md
cp 03_designer.md  .claude/agents/designer.md
cp 04_builder.md   .claude/agents/builder.md
cp 05_reviewer.md  .claude/agents/reviewer.md
cp 06_deployer.md  .claude/agents/deployer.md

# 슬래시 명령 파일
cp commands/plan.md      .claude/commands/plan.md
cp commands/design.md    .claude/commands/design.md
cp commands/generate.md  .claude/commands/generate.md
cp commands/build.md     .claude/commands/build.md
cp commands/review.md    .claude/commands/review.md
cp commands/deploy.md    .claude/commands/deploy.md
```

### 4. 최종 디렉토리 확인

```
my-portfolio/
├── CLAUDE.md
├── .claude/
│   ├── agents/
│   │   ├── planner.md
│   │   ├── architect.md
│   │   ├── designer.md
│   │   ├── builder.md
│   │   ├── reviewer.md
│   │   └── deployer.md
│   └── commands/
│       ├── plan.md
│       ├── design.md
│       ├── generate.md
│       ├── build.md
│       ├── review.md
│       └── deploy.md
├── docs/    (빈 폴더, 산출물 저장될 곳)
└── src/     (빈 폴더, 구현 파일 저장될 곳)
```

---

## 사용 방법

```bash
# 1. 프로젝트 폴더에서 Claude Code 실행
cd my-portfolio
claude

# 2. 순서대로 명령 입력
/plan      # ① 기획 — PRD 작성
/design    # ② 설계 — IA, User Flow, 화면 목록
/generate  # ③ 디자인 — 디자인 시스템 + HTML 시안
/build     # ④ 구현 — 반응형 포트폴리오 HTML
/review    # ⑤ 검증 — 품질 체크
/deploy    # ⑥ 배포 — GitHub Pages / Vercel
```

---

## 단계별 소요 시간 (참고)

| 단계 | 예상 시간 | 산출물 |
|------|---------|--------|
| /plan | 5~10분 | docs/prd.md |
| /design | 10~15분 | docs/ia.md, userflow.md, screens.md |
| /generate | 15~25분 | docs/design-spec.md, src/mockup/ |
| /build | 20~40분 | src/index.html + css + js |
| /review | 10~15분 | docs/review-report.md |
| /deploy | 5~10분 | 라이브 URL |
| **총합** | **65~115분** | **배포 완료 포트폴리오** |

