# Portfolio Pipeline Harness
> 이 파일은 Claude Code가 세션 시작 시 자동으로 읽는 핵심 하네스입니다.
> 프로젝트 루트에 위치해야 합니다.

---

## 프로젝트 정체성

이 프로젝트는 **UIUX 포트폴리오 제작 파이프라인**입니다.
기획 → 설계 → 디자인 → 구현 → 검증 → 배포의 6단계를 순서대로 실행합니다.
각 단계는 전용 서브에이전트가 처리하며, 단계별 산출물은 `docs/` 폴더에 저장됩니다.

---

## 절대 규칙 (반드시 준수)

1. **순서 강제**: 이전 단계 산출물 없이 다음 단계 실행 불가
2. **산출물 저장**: 각 단계 완료 후 docs/ 에 마크다운으로 저장 필수
3. **모바일 퍼스트**: 모든 UI는 375px 기준으로 먼저 설계
4. **한국어 산출물**: 모든 문서는 한국어로 작성 (코드 주석 포함)
5. **에이전트 위임**: 각 단계는 반드시 지정된 서브에이전트에게 위임

---

## 파이프라인 단계 & 슬래시 명령

| 단계 | 명령 | 담당 에이전트 | 산출물 |
|------|------|-------------|--------|
| ① 기획 | `/plan` | planner | `docs/prd.md` |
| ② 설계 | `/design` | architect | `docs/ia.md`, `docs/userflow.md`, `docs/screens.md` |
| ③ 디자인 | `/generate` | designer | `docs/design-spec.md`, `src/mockup/` |
| ④ 구현 | `/build` | builder | `src/index.html`, `src/css/`, `src/js/` |
| ⑤ 검증 | `/review` | reviewer | `docs/review-report.md` |
| ⑥ 배포 | `/deploy` | deployer | 라이브 URL |

---

## 디렉토리 구조

```
프로젝트루트/
├── CLAUDE.md                    ← 지금 이 파일 (하네스)
├── .claude/
│   ├── commands/                ← 슬래시 명령 파일
│   │   ├── plan.md
│   │   ├── design.md
│   │   ├── generate.md
│   │   ├── build.md
│   │   ├── review.md
│   │   └── deploy.md
│   └── agents/                  ← 서브에이전트 파일
│       ├── planner.md
│       ├── architect.md
│       ├── designer.md
│       ├── builder.md
│       ├── reviewer.md
│       └── deployer.md
├── docs/                        ← 모든 산출물 문서
│   ├── prd.md
│   ├── ia.md
│   ├── userflow.md
│   ├── screens.md
│   ├── design-spec.md
│   └── review-report.md
└── src/                         ← 구현 산출물
    ├── index.html
    ├── mockup/
    ├── css/
    │   └── main.css
    └── js/
        └── main.js
```

---

## 디자인 시스템 기준

### 반응형 브레이크포인트
- Mobile: 375px (기본 설계 기준)
- Tablet: 768px
- Desktop: 1280px

### 컬러 시스템 (프로젝트 시작 시 design-spec.md에서 확정)
- Primary: 확정 전 `#000000` 임시값
- Secondary: 확정 전 `#666666` 임시값
- Background: `#ffffff`
- Surface: `#f5f5f5`

### 타이포그래피
- 제목: Bebas Neue (영문) / Noto Sans KR Bold (한글)
- 본문: Noto Sans KR Regular
- 코드/시스템: JetBrains Mono

### 품질 기준
- Lighthouse Performance: 90점 이상
- Lighthouse Accessibility: 90점 이상
- 반응형 3개 뷰포트 모두 검증 필수
- WCAG AA 기준 색상 대비 준수

---

## 에러 발생 시 처리 원칙

- 이전 단계 산출물 누락 → 해당 단계부터 재실행 안내
- 에이전트 오류 → 오류 내용 docs/error-log.md 에 기록 후 재시도
- 파일 충돌 → 기존 파일 백업 후 덮어쓰기

---

## 파이프라인 시작 방법

```
1. 프로젝트 폴더에서 claude 실행
2. /plan 입력하여 기획 단계 시작
3. 각 단계 완료 후 순서대로 다음 명령 실행
```

